class web_interface (private val context:
Context) {
    @JavascriptInterface
    fun showToast(message: String?){
        Toast.makeText(context, message,
Toast.LENGTH_SHORT).show()
    }
}